using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MGK_Analyzer.Models;
using MGK_Analyzer.Services;

namespace MGK_Analyzer.Windows
{
    public partial class ContourWindow : Window, INotifyPropertyChanged
    {
        private string _windowTitle = "Contour Chart";
        public List<Surface3DPoint> DataPoints { get; set; } = new List<Surface3DPoint>();

        public string WindowTitle
        {
            get => _windowTitle;
            set { _windowTitle = value; OnPropertyChanged(); }
        }

        public ContourWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void ContourWindow_Loaded(object sender, RoutedEventArgs e)
        {
            InitializeChartWithData();
        }

        private void InitializeChartWithData()
        {
            if (DataPoints == null || DataPoints.Count == 0)
            {
                // ����� ���� ���� ������ ���
                DataPoints = SampleDataGenerator.CreateSample3DData();
            }

            CreateContourChart();
            UpdateDataInfo();
        }

        private void CreateContourChart()
        {
            if (DataPoints == null || DataPoints.Count == 0) return;
            
            try
            {
                var validPoints = DataPoints.Where(p => !double.IsNaN(p.Z) && !double.IsInfinity(p.Z)).ToList();
                
                if (validPoints.Count == 0)
                {
                    MessageBox.Show("Valid data points not found. All Z values are NaN or Infinity.", 
                                  "Invalid Data", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                
                ContourChart.ItemsSource = validPoints;
                
                var uniqueX = validPoints.Select(p => p.X).Distinct().OrderBy(x => x).ToList();
                var uniqueY = validPoints.Select(p => p.Y).Distinct().OrderBy(y => y).ToList();
                
                ContourChart.RowSize = uniqueY.Count;
                ContourChart.ColumnSize = uniqueX.Count;
                
                ApplyColorPalette();

                // Ensure ColorBar represents Z (Motor_����ȿ��)
                UpdateColorBarFromData(validPoints);

                // Try turn on contour value labels if supported by this Syncfusion version
                SetContourLabelsVisibility(ShowLabelsCheckBox?.IsChecked ?? true);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating contour chart: {ex.Message}", 
                              "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void ApplyColorPalette()
        {
            // SfSurfaceChart�� ��ü ColorBar�� ���
        }

        // Color bar: low(blue) -> high(red), expected Z range ~40..100 (efficiency)
        private void UpdateColorBarFromData(List<Surface3DPoint> points)
        {
            try
            {
                if (points == null || points.Count == 0 || ContourChart?.ColorBar == null) return;

                var minZ = points.Min(p => p.Z);
                var maxZ = points.Max(p => p.Z);

                double rangeMin = Math.Min(40.0, minZ);
                double rangeMax = Math.Max(100.0, maxZ);

                var gradient = new LinearGradientBrush
                {
                    StartPoint = new System.Windows.Point(0, 1),
                    EndPoint = new System.Windows.Point(0, 0)
                };
                gradient.GradientStops.Add(new GradientStop(Colors.Blue, 0.0));
                gradient.GradientStops.Add(new GradientStop(Colors.DeepSkyBlue, 0.2));
                gradient.GradientStops.Add(new GradientStop(Colors.LimeGreen, 0.4));
                gradient.GradientStops.Add(new GradientStop(Colors.Yellow, 0.6));
                gradient.GradientStops.Add(new GradientStop(Colors.Orange, 0.8));
                gradient.GradientStops.Add(new GradientStop(Colors.Red, 1.0));

                try { ContourChart.ColorBar.Background = gradient; } catch { }

                try
                {
                    dynamic colorBar = ContourChart.ColorBar;
                    colorBar.Minimum = rangeMin;
                    colorBar.Maximum = rangeMax;
                }
                catch { }
            }
            catch { }
        }

        private void UpdateDataInfo()
        {
            if (DataPoints != null && DataPoints.Count > 0)
            {
                DataPointsCountText.Text = $"Data Points: {DataPoints.Count}";
                var minZ = DataPoints.Min(p => p.Z);
                var maxZ = DataPoints.Max(p => p.Z);
                ValueRangeText.Text = $"Value Range: {minZ:F2} ~ {maxZ:F2}";
            }
        }

        private void ColorPalette_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (IsLoaded && DataPoints != null && DataPoints.Count > 0)
            {
                ApplyColorPalette();
            }
        }

        private void ContourLevels_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Contour levels can be updated here if needed
        }

        private void ShowLabels_Changed(object sender, RoutedEventArgs e)
        {
            // Toggle both color bar labels and (if available) contour labels on the plot
            var isChecked = ShowLabelsCheckBox?.IsChecked ?? true;
            if (IsLoaded)
            {
                try
                {
                    if (ContourChart?.ColorBar != null)
                    {
                        ContourChart.ColorBar.ShowLabel = isChecked;
                    }
                }
                catch { }

                SetContourLabelsVisibility(isChecked);
            }
        }

        private void ShowLegend_Changed(object sender, RoutedEventArgs e)
        {
            if (IsLoaded && ContourChart?.ColorBar != null)
            {
                var visibility = ShowLegendCheckBox?.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
                if (ContourChart.ColorBar is FrameworkElement colorBar)
                {
                    colorBar.Visibility = visibility;
                }
            }
        }

        private void ResetView_Click(object sender, RoutedEventArgs e)
        {
            CreateContourChart();
        }

        private void ExportChart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var saveDialog = new Microsoft.Win32.SaveFileDialog
                {
                    Filter = "PNG Image|*.png|JPEG Image|*.jpg",
                    FileName = $"ContourChart_{DateTime.Now:yyyyMMdd_HHmmss}"
                };

                if (saveDialog.ShowDialog() == true)
                {
                    var renderBitmap = new RenderTargetBitmap(
                        (int)ContourChart.ActualWidth,
                        (int)ContourChart.ActualHeight,
                        96, 96,
                        PixelFormats.Pbgra32);

                    renderBitmap.Render(ContourChart);

                    BitmapEncoder encoder;
                    if (saveDialog.FileName.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase))
                    {
                        encoder = new JpegBitmapEncoder();
                    }
                    else
                    {
                        encoder = new PngBitmapEncoder();
                    }

                    encoder.Frames.Add(BitmapFrame.Create(renderBitmap));

                    using (var fileStream = new System.IO.FileStream(saveDialog.FileName, System.IO.FileMode.Create))
                    {
                        encoder.Save(fileStream);
                    }

                    MessageBox.Show("Chart exported successfully!", "Export", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// Try to enable/disable contour labels on the chart across Syncfusion versions.
        /// Some versions expose different property names; we use reflection defensively.
        /// </summary>
        private void SetContourLabelsVisibility(bool enabled)
        {
            try
            {
                if (ContourChart == null) return;

                var chartType = ContourChart.GetType();
                var candidateBoolProps = new[]
                {
                    "ShowContourLabels", // common guess
                    "ShowContourLabel",
                    "IsContourLabelVisible",
                    "IsLabelVisible"
                };

                foreach (var name in candidateBoolProps)
                {
                    var prop = chartType.GetProperty(name);
                    if (prop != null && prop.PropertyType == typeof(bool) && prop.CanWrite)
                    {
                        prop.SetValue(ContourChart, enabled);
                        return;
                    }
                }

                // Enum-based visibility (e.g., ContourLabelVisibility)
                var enumProp = chartType.GetProperty("ContourLabelVisibility");
                if (enumProp != null && enumProp.CanWrite && enumProp.PropertyType.IsEnum)
                {
                    var values = Enum.GetNames(enumProp.PropertyType);
                    object valueToSet = enabled
                        ? Enum.Parse(enumProp.PropertyType, values.FirstOrDefault(v => v.Equals("Visible", StringComparison.OrdinalIgnoreCase)) ?? values.First())
                        : Enum.Parse(enumProp.PropertyType, values.FirstOrDefault(v => v.Equals("Collapsed", StringComparison.OrdinalIgnoreCase)) ?? values.Last());
                    enumProp.SetValue(ContourChart, valueToSet);
                    return;
                }
            }
            catch
            {
                // Swallow ? property may not exist in this version.
            }
        }
    }
}
