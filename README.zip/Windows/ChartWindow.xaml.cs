using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using MGK_Analyzer.Models;
using MGK_Analyzer.Services;
using Syncfusion.UI.Xaml.Charts;

namespace MGK_Analyzer.Windows
{
    public partial class ChartWindow : Window, INotifyPropertyChanged
    {
        private MemoryOptimizedDataSet? _dataSet;
        private string _windowTitle = "Chart Window";

        public string WindowTitle
        {
            get => _windowTitle;
            set { _windowTitle = value; OnPropertyChanged(); }
        }

        public MemoryOptimizedDataSet? DataSet
        {
            get => _dataSet;
            set 
            { 
                using var timer = PerformanceLogger.Instance.StartTimer("��Ʈ ������ ������ ����", "Chart_Display");
                
                _dataSet = value; 
                OnPropertyChanged();
                
                PerformanceLogger.Instance.LogInfo($"��Ʈ ������ ���� - ����: {value?.FileName}, �ø���: {value?.SeriesData?.Count}", "Chart_Display");
                InitializeSeriesList();
            }
        }

        public ObservableCollection<ChartSeriesViewModel> SeriesList { get; set; } = new ObservableCollection<ChartSeriesViewModel>();

        public ChartWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void InitializeSeriesList()
        {
            using var timer = PerformanceLogger.Instance.StartTimer("�ø��� ����Ʈ �ʱ�ȭ", "Chart_Display");
            
            SeriesList.Clear();
            if (DataSet?.SeriesData != null)
            {
                foreach (var series in DataSet.SeriesData.Values)
                {
                    var viewModel = new ChartSeriesViewModel { SeriesData = series };
                    viewModel.PropertyChanged += SeriesViewModel_PropertyChanged;
                    SeriesList.Add(viewModel);
                }
                
                PerformanceLogger.Instance.LogInfo($"�ø��� ����Ʈ �ʱ�ȭ �Ϸ� - {SeriesList.Count}�� �ø���", "Chart_Display");
            }
        }

        private async void SeriesViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ChartSeriesViewModel.IsSelected))
            {
                var viewModel = (ChartSeriesViewModel)sender;
                var seriesName = viewModel.SeriesData.Name;
                
                PerformanceLogger.Instance.LogInfo($"�ø��� ���� ����: {seriesName} -> {viewModel.IsSelected}", "Chart_Display");
                
                if (viewModel.IsSelected)
                {
                    await Task.Run(() =>
                    {
                        using var timer = PerformanceLogger.Instance.StartTimer($"�ø��� �߰�: {seriesName}", "Chart_Display");
                        Dispatcher.BeginInvoke(() => AddSeriesToChart(viewModel.SeriesData));
                    });
                }
                else
                {
                    using var timer = PerformanceLogger.Instance.StartTimer($"�ø��� ����: {seriesName}", "Chart_Display");
                    RemoveSeriesFromChart(viewModel.SeriesData);
                }
            }
        }

        private void AddSeriesToChart(SeriesData series)
        {
            using var overallTimer = PerformanceLogger.Instance.StartTimer($"��ü ��Ʈ �ø��� �߰�: {series.Name}", "Chart_Display");
            
            if (DataSet == null || DataSet.TotalSamples == 0) return;
            
            var maxPoints = 500;
            var totalPoints = DataSet.TotalSamples;
            var step = Math.Max(1, totalPoints / maxPoints);
            
            PerformanceLogger.Instance.LogInfo($"�ٿ���ø� ���� - ��ü: {totalPoints:N0}, �ܰ�: {step}, ǥ��: {totalPoints/step:N0}�� ����Ʈ", "Chart_Display");
            
            try
            {
                if (series.DataType == typeof(bool))
                {
                    using var seriesTimer = PerformanceLogger.Instance.StartTimer($"StepLine �ø��� ����: {series.Name}", "Chart_Display");
                    
                    var stepSeries = new StepLineSeries
                    {
                        XBindingPath = "Time",
                        YBindingPath = "Value",
                        Label = series.Name,
                        Stroke = series.Color,
                        StrokeThickness = 1
                    };

                    var dataPoints = CreateBoolDataPoints(series, step);
                    stepSeries.ItemsSource = dataPoints;
                    ChartControl.Series.Add(stepSeries);
                    
                    PerformanceLogger.Instance.LogInfo($"Bool �ø��� �߰� �Ϸ�: {series.Name} ({dataPoints.Count:N0}�� ����Ʈ)", "Chart_Display");
                }
                else
                {
                    using var seriesTimer = PerformanceLogger.Instance.StartTimer($"Line �ø��� ����: {series.Name}", "Chart_Display");
                    
                    var lineSeries = new LineSeries
                    {
                        XBindingPath = "Time",
                        YBindingPath = "Value",
                        Label = series.Name,
                        Stroke = series.Color,
                        StrokeThickness = 1
                    };

                    var dataPoints = CreateDoubleDataPoints(series, step);
                    lineSeries.ItemsSource = dataPoints;
                    ChartControl.Series.Add(lineSeries);
                    
                    PerformanceLogger.Instance.LogInfo($"Double �ø��� �߰� �Ϸ�: {series.Name} ({dataPoints.Count:N0}�� ����Ʈ)", "Chart_Display");
                }
            }
            catch (Exception ex)
            {
                PerformanceLogger.Instance.LogError($"�ø��� �߰� ����: {series.Name} - {ex.Message}", "Chart_Display");
            }
            
            if (ChartControl.Legend is ChartLegend legend)
            {
                legend.Visibility = Visibility.Visible;
            }
            
            PerformanceLogger.Instance.LogInfo($"���� ��Ʈ�� �� �ø��� ��: {ChartControl.Series.Count}", "Chart_Display");
        }

        private ObservableCollection<ChartDataPoint> CreateBoolDataPoints(SeriesData series, int step)
        {
            using var timer = PerformanceLogger.Instance.StartTimer($"Bool ������ ����Ʈ ����: {series.Name}", "Chart_Display");
            
            var dataPoints = new ObservableCollection<ChartDataPoint>();
            var pointCount = 0;
            
            for (int i = 0; i < DataSet.TotalSamples && pointCount < 10000; i += step)
            {
                bool value = GetBoolValue(series.BitValues, i);
                dataPoints.Add(new ChartDataPoint
                {
                    Time = DataSet.GetTimeAt(i),
                    Value = value ? 1.0 : 0.0,
                    SeriesName = series.Name
                });
                pointCount++;
            }
            
            PerformanceLogger.Instance.LogInfo($"Bool ������ ����Ʈ ���� �Ϸ�: {pointCount:N0}��", "Chart_Display");
            return dataPoints;
        }

        private ObservableCollection<ChartDataPoint> CreateDoubleDataPoints(SeriesData series, int step)
        {
            using var timer = PerformanceLogger.Instance.StartTimer($"Double ������ ����Ʈ ����: {series.Name}", "Chart_Display");
            
            var dataPoints = new ObservableCollection<ChartDataPoint>();
            var pointCount = 0;
            var maxPointsToCreate = 500;
            
            if (series.Values == null || series.Values.Length == 0)
            {
                return dataPoints;
            }
            
            var maxSafeIndex = Math.Min(DataSet.TotalSamples, series.Values.Length);
            
            for (int i = 0; i < maxSafeIndex && pointCount < maxPointsToCreate; i += step)
            {
                try
                {
                    var time = DataSet.GetTimeAt(i);
                    var value = series.Values[i];
                    
                    if (float.IsNaN(value) || float.IsInfinity(value))
                    {
                        continue;
                    }
                    
                    dataPoints.Add(new ChartDataPoint
                    {
                        Time = time,
                        Value = value,
                        SeriesName = series.Name
                    });
                    
                    pointCount++;
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"ERROR: ������ ����Ʈ ���� �� ���� (�ε��� {i}): {ex.Message}");
                    break;
                }
            }
            
            PerformanceLogger.Instance.LogInfo($"Double ������ ����Ʈ ���� �Ϸ�: {pointCount:N0}��", "Chart_Display");
            
            return dataPoints;
        }

        private void RemoveSeriesFromChart(SeriesData series)
        {
            var seriesToRemove = ChartControl.Series.FirstOrDefault(s => 
                s.Label?.ToString() == series.Name);
            if (seriesToRemove != null)
            {
                ChartControl.Series.Remove(seriesToRemove);
            }
        }

        private bool GetBoolValue(byte[] bitValues, int index)
        {
            if (bitValues == null) return false;
            int byteIndex = index / 8;
            int bitIndex = index % 8;
            return byteIndex < bitValues.Length && (bitValues[byteIndex] & (1 << bitIndex)) != 0;
        }

        private void ExportChart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var saveDialog = new Microsoft.Win32.SaveFileDialog
                {
                    Filter = "PNG Image|*.png|JPEG Image|*.jpg",
                    FileName = $"Chart_{DateTime.Now:yyyyMMdd_HHmmss}"
                };

                if (saveDialog.ShowDialog() == true)
                {
                    MessageBox.Show("Export functionality will be implemented in the next phase.", 
                                   "Export Chart", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed: {ex.Message}", "Error", 
                               MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
