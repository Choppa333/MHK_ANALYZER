using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MGK_Analyzer.Models;
using MGK_Analyzer.Services;
using Syncfusion.UI.Xaml.Charts;
using System.Diagnostics;

namespace MGK_Analyzer.Controls
{
    public partial class MdiContourWindow : UserControl, INotifyPropertyChanged
    {
        public static readonly DependencyProperty WindowTitleProperty =
            DependencyProperty.Register("WindowTitle", typeof(string), typeof(MdiContourWindow),
            new PropertyMetadata("Contour Chart"));

        public string WindowTitle
        {
            get => (string)GetValue(WindowTitleProperty);
            set => SetValue(WindowTitleProperty, value);
        }

        public List<Surface3DPoint> DataPoints { get; set; } = new List<Surface3DPoint>();

        private bool _isResizing = false;
        private bool _isDragging = false;
        private Point _startPoint;
        private ResizeDirection _resizeDirection = ResizeDirection.None;
        private double _resizeStartWidth;
        private double _resizeStartHeight;
        private double _resizeStartLeft;
        private double _resizeStartTop;
        private bool _isPanelPinned = false;
        private static int _globalZIndex = 1;
        
        private double _normalWidth = 1000;
        private double _normalHeight = 700;
        private double _normalLeft = 0;
        private double _normalTop = 0;
        private bool _isMaximized = false;
        private bool _isMinimized = false;

        public event EventHandler? WindowClosed;
        public event EventHandler? WindowMinimized;
        public event EventHandler? WindowMaximized;

        private readonly List<Surface3DPoint> _feedBuffer = new();
        private int _feedIndex = 0;

        public MdiContourWindow()
        {
            InitializeComponent();
            this.PreviewMouseDown += (_, __) => MGK_Analyzer.Services.MdiZOrderService.BringToFront(this);
        }

        private void MdiContourWindow_Loaded(object sender, RoutedEventArgs e)
        {
            InitializeChartWithData();
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_isDragging && e.LeftButton == MouseButtonState.Pressed)
            {
                var canvas = (Canvas?)this.Parent;
                if (canvas == null) return;

                var currentPosition = e.GetPosition(canvas);
                var deltaX = currentPosition.X - _startPoint.X;
                var deltaY = currentPosition.Y - _startPoint.Y;
                var newLeft = Canvas.GetLeft(this) + deltaX;
                var newTop = Canvas.GetTop(this) + deltaY;
                newLeft = Math.Max(0, Math.Min(newLeft, canvas.ActualWidth - this.ActualWidth));
                newTop = Math.Max(0, Math.Min(newTop, canvas.ActualHeight - this.ActualHeight));
                Canvas.SetLeft(this, newLeft);
                Canvas.SetTop(this, newTop);
                _startPoint = currentPosition;
            }
            
            if (_isResizing && e.LeftButton == MouseButtonState.Pressed)
            {
                var canvas = (Canvas?)this.Parent;
                if (canvas == null) return;
                var currentPosition = e.GetPosition(canvas);
                PerformResize(currentPosition);
            }

            base.OnMouseMove(e);
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
        {
            if (_isDragging || _isResizing)
            {
                _isDragging = false;
                _isResizing = false;
                _resizeDirection = ResizeDirection.None;
                this.ReleaseMouseCapture();
            }
            base.OnMouseLeftButtonUp(e);
        }

        private void InitializeChartWithData()
        {
            if (DataPoints == null || DataPoints.Count == 0)
            {
                ContourChart.ItemsSource = null;
                UpdateDataInfo();
                return;
            }

            _feedBuffer.Clear();
            _feedBuffer.AddRange(DataPoints);
            _feedIndex = _feedBuffer.Count;
            UpdateFeedStatus();

            CreateContourChart();
            UpdateDataInfo();
        }

        private void CreateContourChart()
        {
            Debug.WriteLine($"[Contour] CreateContourChart - Using full sample set: {_feedBuffer.Count} points");

            var input = _feedBuffer;
            if (input.Count == 0)
            {
                ContourChart.ItemsSource = null;
                return;
            }

            try
            {
                var validPoints = input.Where(p => !double.IsNaN(p.Z) && !double.IsInfinity(p.Z)).ToList();
                if (validPoints.Count == 0)
                {
                    ContourChart.ItemsSource = null;
                    return;
                }

                double minX = validPoints.Min(p => p.X), maxX = validPoints.Max(p => p.X);
                double minY = validPoints.Min(p => p.Y), maxY = validPoints.Max(p => p.Y);
                const int columnSize = 60;
                const int rowSize = 40;
                var xs = LinSpace(minX, maxX, columnSize);
                var ys = LinSpace(minY, maxY, rowSize);

                var grid = new List<Surface3DPoint>(rowSize * columnSize);
                for (int ry = 0; ry < rowSize; ry++)
                {
                    double y = ys[ry];
                    for (int cx = 0; cx < columnSize; cx++)
                    {
                        double x = xs[cx];
                        double z = IdwAt(x, y, validPoints, power: 2.0, eps: 1e-9);
                        z = Math.Max(50.0, Math.Min(98.0, z));
                        grid.Add(new Surface3DPoint(x, y, z));
                    }
                }

                grid = grid.OrderBy(p => p.Y).ThenBy(p => p.X).ToList();

                ContourChart.RowSize = rowSize;
                ContourChart.ColumnSize = columnSize;
                ContourChart.ItemsSource = grid;

                UpdateColorBarFromData(grid, fixedMin: 50.0, fixedMax: 98.0);
                ApplyZRangeToAxisAndColorBar(grid);
                try { TrySetProperty(ContourChart.ColorBar, "Minimum", 50.0); TrySetProperty(ContourChart.ColorBar, "Maximum", 98.0); } catch { }

                UpdateYAxisOverlay(minY, maxY);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[Contour] ����: {ex.Message}");
            }
        }

        private static double[] LinSpace(double min, double max, int n)
        {
            if (n <= 1) return new[] { min };
            var a = new double[n];
            double step = (max - min) / (n - 1);
            for (int i = 0; i < n; i++) a[i] = min + step * i;
            return a;
        }

        private static double IdwAt(double x, double y, List<Surface3DPoint> pts, double power = 2.0, double eps = 1e-9)
        {
            double num = 0, den = 0;
            foreach (var p in pts)
            {
                double dx = x - p.X;
                double dy = y - p.Y;
                double d2 = dx * dx + dy * dy;
                if (d2 < eps) return p.Z;
                double w = 1.0 / Math.Pow(d2, power / 2.0);
                num += w * p.Z;
                den += w;
            }
            return num / Math.Max(den, eps);
        }

        private void ApplyColorPalette()
        {
            var palette = ColorPaletteComboBox?.SelectedItem as ComboBoxItem;
            var paletteName = palette?.Content?.ToString() ?? "Rainbow";
            Debug.WriteLine($"[Contour] Color Palette ����: {paletteName}");
        }

        private void UpdateColorBarFromData(List<Surface3DPoint> points, double? fixedMin = null, double? fixedMax = null)
        {
            try
            {
                if (points == null || points.Count == 0 || ContourChart?.ColorBar == null) return;

                var minZ = fixedMin ?? points.Min(p => p.Z);
                var maxZ = fixedMax ?? points.Max(p => p.Z);

                var gradient = new LinearGradientBrush
                {
                    StartPoint = new System.Windows.Point(0, 1),
                    EndPoint = new System.Windows.Point(0, 0)
                };
                gradient.GradientStops.Add(new GradientStop(Colors.Blue, 0.0));
                gradient.GradientStops.Add(new GradientStop(Colors.Green, 0.33));
                gradient.GradientStops.Add(new GradientStop(Colors.Yellow, 0.66));
                gradient.GradientStops.Add(new GradientStop(Colors.Red, 1.0));

                try { ContourChart.ColorBar.Background = gradient; } catch { }

                try
                {
                    var colorBar = ContourChart.ColorBar;
                    if (colorBar != null)
                    {
                        TrySetProperty(colorBar, "Minimum", minZ);
                        TrySetProperty(colorBar, "Maximum", maxZ);
                        TrySetProperty(colorBar, "Interval", (maxZ - minZ) / 8.0);
                        TrySetProperty(colorBar, "SegmentCount", 8);
                        TrySetProperty(colorBar, "ItemsCount", 8);
                        TrySetProperty(colorBar, "Levels", 8);
                        colorBar.ShowLabel = true;
                    }
                }
                catch { }
            }
            catch { }
        }

        private void ApplyZRangeToAxisAndColorBar(List<Surface3DPoint> points)
        {
            try
            {
                if (ContourChart == null || points == null || points.Count == 0) return;
                var minZ = points.Min(p => p.Z);
                var maxZ = points.Max(p => p.Z);
                var minX = points.Min(p => p.X);
                var maxX = points.Max(p => p.X);
                var minY = points.Min(p => p.Y);
                var maxY = points.Max(p => p.Y);

                try
                {
                    ContourChart.XAxis.Minimum = minX;
                    ContourChart.XAxis.Maximum = maxX;
                    ContourChart.YAxis.Minimum = minY;
                    ContourChart.YAxis.Maximum = maxY;
                    try { ContourChart.YAxis.Interval = Math.Max(1, (maxY - minY) / 6.0); } catch { TrySetProperty(ContourChart.YAxis, "Interval", Math.Max(1, (maxY - minY) / 6.0)); }
                    TrySetProperty(ContourChart.YAxis, "LabelFormat", (maxY - minY) > 50 ? "0" : "0.0");
                    ContourChart.ZAxis.Minimum = minZ;
                    ContourChart.ZAxis.Maximum = maxZ;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[Contour] Axis range set failed: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[Contour] ApplyZRangeToAxisAndColorBar ����: {ex.Message}");
            }
        }

        private static void TrySetProperty(object target, string propertyName, object value)
        {
            try
            {
                var p = target.GetType().GetProperty(propertyName);
                if (p != null && p.CanWrite)
                {
                    var v = Convert.ChangeType(value, p.PropertyType);
                    p.SetValue(target, v);
                }
            }
            catch { }
        }

        private void UpdateYAxisOverlay(double minY, double maxY)
        {
            try
            {
                double step = (maxY - minY) / 4.0;
                if (YTick0 != null) YTick0.Text = minY.ToString("F1");
                if (YTick1 != null) YTick1.Text = (minY + step).ToString("F1");
                if (YTick2 != null) YTick2.Text = (minY + 2 * step).ToString("F1");
                if (YTick3 != null) YTick3.Text = (minY + 3 * step).ToString("F1");
                if (YTick4 != null) YTick4.Text = maxY.ToString("F1");
            }
            catch { }
        }

        private void UpdateDataInfo()
        {
            if (DataPoints != null && DataPoints.Count > 0)
            {
                DataPointsCountText.Text = $"Data Points: {DataPoints.Count}";
                var minZ = DataPoints.Min(p => p.Z);
                var maxZ = DataPoints.Max(p => p.Z);
                ValueRangeText.Text = $"Value Range: {minZ:F2} ~ {maxZ:F2}";
            }
        }

        private void ResetFeed_Click(object sender, RoutedEventArgs e)
        {
            _feedBuffer.Clear();
            _feedBuffer.AddRange(DataPoints);
            _feedIndex = _feedBuffer.Count;
            UpdateFeedStatus();
            CreateContourChart();
        }

        private void AddNextPoint_Click(object sender, RoutedEventArgs e)
        {
            _feedIndex = _feedBuffer.Count;
            UpdateFeedStatus();
            CreateContourChart();
        }

        private void UpdateFeedStatus()
        {
            try
            {
                if (FeedStatusText != null)
                {
                    FeedStatusText.Text = $"Added: {_feedIndex} / {_feedBuffer.Count}";
                }
            }
            catch { }
        }

        public void Close_Click(object? sender, RoutedEventArgs? e)
        {
            WindowClosed?.Invoke(this, EventArgs.Empty);
        }

        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            if (_isMinimized)
            {
                RestoreNormalSize();
            }
            else
            {
                SaveCurrentSize();
                this.Height = 30;
                _isMinimized = true;
                _isMaximized = false;
            }
        }

        private void Maximize_Click(object sender, RoutedEventArgs e)
        {
            var canvas = (Canvas?)this.Parent;
            if (canvas == null) return;
            
            if (_isMaximized)
            {
                RestoreNormalSize();
            }
            else
            {
                SaveCurrentSize();
                this.Width = canvas.ActualWidth - 10;
                this.Height = canvas.ActualHeight - 10;
                Canvas.SetLeft(this, 5);
                Canvas.SetTop(this, 5);
                _isMaximized = true;
                _isMinimized = false;
            }
        }
        
        private void SaveCurrentSize()
        {
            if (!_isMaximized && !_isMinimized)
            {
                _normalWidth = this.ActualWidth;
                _normalHeight = this.ActualHeight;
                _normalLeft = Canvas.GetLeft(this);
                _normalTop = Canvas.GetTop(this);
            }
        }
        
        private void RestoreNormalSize()
        {
            this.Width = _normalWidth;
            this.Height = _normalHeight;
            Canvas.SetLeft(this, _normalLeft);
            Canvas.SetTop(this, _normalTop);
            _isMaximized = false;
            _isMinimized = false;
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var element = e.OriginalSource as FrameworkElement;
            while (element != null)
            {
                if (element is Button)
                {
                    return;
                }
                element = element.Parent as FrameworkElement;
            }

            if (e.ClickCount == 2)
            {
                Maximize_Click(sender, e);
            }
            else
            {
                var canvas = Parent as Canvas;
                if (canvas != null)
                {
                    MGK_Analyzer.Services.MdiZOrderService.BringToFront(this);
                    _startPoint = e.GetPosition(canvas);
                    _isDragging = true;
                    this.CaptureMouse();
                    e.Handled = true;
                }
            }
        }

        private void ResizeTop_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            StartResize(ResizeDirection.Top, e.GetPosition(Parent as Canvas));
            e.Handled = true;
        }

        private void ResizeBottom_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            StartResize(ResizeDirection.Bottom, e.GetPosition(Parent as Canvas));
            e.Handled = true;
        }

        private void ResizeLeft_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            StartResize(ResizeDirection.Left, e.GetPosition(Parent as Canvas));
            e.Handled = true;
        }

        private void ResizeRight_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            StartResize(ResizeDirection.Right, e.GetPosition(Parent as Canvas));
            e.Handled = true;
        }

        private void ResizeTopLeft_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            StartResize(ResizeDirection.TopLeft, e.GetPosition(Parent as Canvas));
            e.Handled = true;
        }

        private void ResizeTopRight_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            StartResize(ResizeDirection.TopRight, e.GetPosition(Parent as Canvas));
            e.Handled = true;
        }

        private void ResizeBottomLeft_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            StartResize(ResizeDirection.BottomLeft, e.GetPosition(Parent as Canvas));
            e.Handled = true;
        }

        private void ResizeBottomRight_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            StartResize(ResizeDirection.BottomRight, e.GetPosition(Parent as Canvas));
            e.Handled = true;
        }

        private void StartResize(ResizeDirection direction, Point startPosition)
        {
            var canvas = Parent as Canvas;
            if (canvas == null) return;

            _isResizing = true;
            _resizeDirection = direction;
            _startPoint = startPosition;
            _resizeStartWidth = this.ActualWidth;
            _resizeStartHeight = this.ActualHeight;
            _resizeStartLeft = Canvas.GetLeft(this);
            _resizeStartTop = Canvas.GetTop(this);
            this.CaptureMouse();
            MGK_Analyzer.Services.MdiZOrderService.BringToFront(this);
        }

        private void PerformResize(Point currentPosition)
        {
            var canvas = (Canvas?)this.Parent;
            if (canvas == null) return;

            var deltaX = currentPosition.X - _startPoint.X;
            var deltaY = currentPosition.Y - _startPoint.Y;

            var newWidth = _resizeStartWidth;
            var newHeight = _resizeStartHeight;
            var newLeft = _resizeStartLeft;
            var newTop = _resizeStartTop;

            const double minWidth = 300;
            const double minHeight = 200;

            switch (_resizeDirection)
            {
                case ResizeDirection.Right:
                    newWidth = Math.Max(minWidth, _resizeStartWidth + deltaX);
                    break;
                case ResizeDirection.Bottom:
                    newHeight = Math.Max(minHeight, _resizeStartHeight + deltaY);
                    break;
                case ResizeDirection.Left:
                    var newWidthLeft = Math.Max(minWidth, _resizeStartWidth - deltaX);
                    if (newWidthLeft >= minWidth)
                    {
                        newWidth = newWidthLeft;
                        newLeft = _resizeStartLeft + deltaX;
                    }
                    break;
                case ResizeDirection.Top:
                    var newHeightTop = Math.Max(minHeight, _resizeStartHeight - deltaY);
                    if (newHeightTop >= minHeight)
                    {
                        newHeight = newHeightTop;
                        newTop = _resizeStartTop + deltaY;
                    }
                    break;
                case ResizeDirection.TopLeft:
                    var newWidthTL = Math.Max(minWidth, _resizeStartWidth - deltaX);
                    var newHeightTL = Math.Max(minHeight, _resizeStartHeight - deltaY);
                    if (newWidthTL >= minWidth && newHeightTL >= minHeight)
                    {
                        newWidth = newWidthTL;
                        newHeight = newHeightTL;
                        newLeft = _resizeStartLeft + deltaX;
                        newTop = _resizeStartTop + deltaY;
                    }
                    break;
                case ResizeDirection.TopRight:
                    var newWidthTR = Math.Max(minWidth, _resizeStartWidth + deltaX);
                    var newHeightTR = Math.Max(minHeight, _resizeStartHeight - deltaY);
                    if (newWidthTR >= minWidth && newHeightTR >= minHeight)
                    {
                        newWidth = newWidthTR;
                        newHeight = newHeightTR;
                        newTop = _resizeStartTop + deltaY;
                    }
                    break;
                case ResizeDirection.BottomLeft:
                    var newWidthBL = Math.Max(minWidth, _resizeStartWidth - deltaX);
                    var newHeightBL = Math.Max(minHeight, _resizeStartHeight + deltaY);
                    if (newWidthBL >= minWidth && newHeightBL >= minHeight)
                    {
                        newWidth = newWidthBL;
                        newHeight = newHeightBL;
                        newLeft = _resizeStartLeft + deltaX;
                    }
                    break;
                case ResizeDirection.BottomRight:
                    newWidth = Math.Max(minWidth, _resizeStartWidth + deltaX);
                    newHeight = Math.Max(minHeight, _resizeStartHeight + deltaY);
                    break;
            }

            if (newLeft >= 0 && newLeft + newWidth <= canvas.ActualWidth &&
                newTop >= 0 && newTop + newHeight <= canvas.ActualHeight)
            {
                this.Width = newWidth;
                this.Height = newHeight;
                Canvas.SetLeft(this, newLeft);
                Canvas.SetTop(this, newTop);
            }
        }

        private void PanelPinButton_Checked(object sender, RoutedEventArgs e)
        {
            _isPanelPinned = true;
        }

        private void PanelPinButton_Unchecked(object sender, RoutedEventArgs e)
        {
            _isPanelPinned = false;
        }

        private void ManagementPanel_MouseLeave(object sender, MouseEventArgs e)
        {
            if (!_isPanelPinned)
            {
                var timer = new System.Windows.Threading.DispatcherTimer();
                timer.Interval = TimeSpan.FromMilliseconds(300);
                timer.Tick += (s, args) =>
                {
                    timer.Stop();
                    if (!_isPanelPinned && !ManagementPanel.IsMouseOver)
                    {
                        var storyboard = FindResource("SlideOutStoryboard") as System.Windows.Media.Animation.Storyboard;
                        storyboard?.Begin();
                        ManagementPanelTab.Visibility = Visibility.Visible;
                    }
                };
                timer.Start();
            }
        }

        private void ManagementPanelTab_MouseEnter(object sender, MouseEventArgs e)
        {
            var storyboard = FindResource("SlideInStoryboard") as System.Windows.Media.Animation.Storyboard;
            storyboard?.Begin();
            ManagementPanelTab.Visibility = Visibility.Collapsed;
        }

        private void ManagementPanelTab_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var storyboard = FindResource("SlideInStoryboard") as System.Windows.Media.Animation.Storyboard;
            storyboard?.Begin();
            ManagementPanelTab.Visibility = Visibility.Collapsed;
        }

        private void ColorPalette_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (IsLoaded && DataPoints != null && DataPoints.Count > 0)
            {
                ApplyColorPalette();
            }
        }

        private void ContourLevels_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (IsLoaded && DataPoints != null && DataPoints.Count > 0)
            {
                // auto managed by UpdateColorBarFromData
            }
        }

        private void ShowLabels_Changed(object sender, RoutedEventArgs e)
        {
            if (IsLoaded && ContourChart?.ColorBar != null)
            {
                ContourChart.ColorBar.ShowLabel = ShowLabelsCheckBox?.IsChecked ?? true;
            }
        }

        private void ShowLegend_Changed(object sender, RoutedEventArgs e)
        {
            if (IsLoaded && ContourChart?.ColorBar != null)
            {
                var visibility = ShowLegendCheckBox?.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
                if (ContourChart.ColorBar is FrameworkElement colorBar)
                {
                    colorBar.Visibility = visibility;
                }
            }
        }

        private void ResetView_Click(object sender, RoutedEventArgs e)
        {
            CreateContourChart();
        }

        private void ExportChart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var saveDialog = new Microsoft.Win32.SaveFileDialog
                {
                    Filter = "PNG Image|*.png|JPEG Image|*.jpg",
                    FileName = $"ContourChart_{DateTime.Now:yyyyMMdd_HHmmss}"
                };

                if (saveDialog.ShowDialog() == true)
                {
                    var renderBitmap = new RenderTargetBitmap(
                        (int)ContourChart.ActualWidth,
                        (int)ContourChart.ActualHeight,
                        96, 96,
                        PixelFormats.Pbgra32);

                    renderBitmap.Render(ContourChart);

                    BitmapEncoder encoder;
                    if (saveDialog.FileName.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase))
                    {
                        encoder = new JpegBitmapEncoder();
                    }
                    else
                    {
                        encoder = new PngBitmapEncoder();
                    }

                    encoder.Frames.Add(BitmapFrame.Create(renderBitmap));

                    using (var fileStream = new System.IO.FileStream(saveDialog.FileName, System.IO.FileMode.Create))
                    {
                        encoder.Save(fileStream);
                    }

                    MessageBox.Show("Chart exported successfully!", "Export", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SetSmallSize_Click(object sender, RoutedEventArgs e)
        {
            SetWindowSize(400, 300);
        }

        private void SetMediumSize_Click(object sender, RoutedEventArgs e)
        {
            SetWindowSize(800, 600);
        }

        private void SetLargeSize_Click(object sender, RoutedEventArgs e)
        {
            SetWindowSize(1200, 800);
        }

        private void SetHDSize_Click(object sender, RoutedEventArgs e)
        {
            var canvas = (Canvas)this.Parent;
            if (canvas != null)
            {
                var maxWidth = Math.Min(1920, canvas.ActualWidth - 50);
                var maxHeight = Math.Min(1080, canvas.ActualHeight - 50);
                SetWindowSize(maxWidth, maxHeight);
            }
            else
            {
                SetWindowSize(1200, 800);
            }
        }

        private void ShowCustomSizeDialog_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new CustomSizeDialog(this.ActualWidth, this.ActualHeight)
            {
                Owner = Window.GetWindow(this)
            };

            if (dialog.ShowDialog() == true)
            {
                SetWindowSize(dialog.SelectedWidth, dialog.SelectedHeight);
            }
        }

        private void SetWindowSize(double width, double height)
        {
            var canvas = (Canvas)this.Parent;
            if (canvas == null) return;

            const double minWidth = 300;
            const double minHeight = 200;
            
            width = Math.Max(minWidth, Math.Min(width, canvas.ActualWidth - 20));
            height = Math.Max(minHeight, Math.Min(height, canvas.ActualHeight - 20));

            var currentLeft = Canvas.GetLeft(this);
            var currentTop = Canvas.GetTop(this);
            
            if (currentLeft + width > canvas.ActualWidth)
            {
                currentLeft = Math.Max(0, canvas.ActualWidth - width);
                Canvas.SetLeft(this, currentLeft);
            }
            
            if (currentTop + height > canvas.ActualHeight)
            {
                currentTop = Math.Max(0, canvas.ActualHeight - height);
                Canvas.SetTop(this, currentTop);
            }

            this.Width = width;
            this.Height = height;
            
            _isMaximized = false;
            _isMinimized = false;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
